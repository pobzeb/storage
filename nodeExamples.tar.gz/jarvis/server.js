// Pull in requirements.
var fs         = require('fs');
var express    = require('express');
var http       = require('http');
var bodyParser = require('body-parser');
var zmq        = require('zmq');

// Create the app.
var app        = express();

// Usage message.
var Usage      = 'Usage: node server.js --config <PATH_TO_CONFIG>';

// Mode and db values.
var mode = 'dev';

// Load up the configuration file.
if (process.argv.length > 2) {
	var paramType = '';
	for (var idx = 2; idx < process.argv.length; idx++) {
		if (process.argv[idx].indexOf('--') == 0) {
			paramType = process.argv[idx].substr(2);
		}
		else {
			switch (paramType.toLowerCase()) {
				case 'config': {
					console.log('Loading Config: ' + process.argv[idx]);
					var configLines = fs.readFileSync(process.argv[idx], 'utf-8').split('\n');
					for (var lineIdx = 0; lineIdx < configLines.length; lineIdx++) {
						var key = configLines[lineIdx].split('=')[0];
						var val = configLines[lineIdx].split('=')[1];
						switch (key.toLowerCase()) {
							case 'mode': {
								if (val.toLowerCase() !== 'prod')
									mode = 'dev';
								else
									mode = 'prod';
								break;
							}
						}
					}
					break;
				}
				default: {}
			}
		}
	}
}
else {
	console.error(usage);
	return;
}

console.log('Application Mode: '+mode);

// Used to parse json body.
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Hold the socket message.
var sockMessage = undefined;

// Connect to the controller server.
var socket = zmq.socket('sub');
socket.on('message', function(msg) {
	sockMessage = msg.toString();
});

// Specify port.
var port = process.env.PORT || 80;

// Set up our routes.
var router = express.Router();
router.use(function(req, res, next) {
	// Interceptor.
	// Verify authentication if not GET request.
	next();
});

router.route('/authenticate/:operator')
	.get(function(req, res) {
		res.json({'operator': req.params.operator, message: sockMessage});
	});

router.route('/events')
	.get(function(req, res) {
		req.socket.setTimeout(Infinity);

		var reqSocket = zmq.socket('sub');
		reqSocket.on('message', function(msg) {
			res.write('id: Controller\n');
			res.write('data: '+msg.toString()+'\n\n');
		});

		// Connect the socket.
		reqSocket.connect('tcp://localhost:5555');
		reqSocket.subscribe('');

		res.writeHead(200, {
			'Content-Type': 'text/event-stream',
			'Cache-Control': 'no-cache',
			'Connection': 'keep-alive'
		});
		res.write('\n');

		req.on('close', function() {
			reqSocket.close();
		});
	});

// router.route('/athlete/:athlete_id')
// 	.get(function(req, res) {
// 		Athlete.findById(req.params.athlete_id, function(err, athlete) {
// 			if (err) {
// 				console.error(err);
// 				res.send(err);
// 				return;
// 			}

// 			res.json(athlete);
// 		});
// 	});

// Add static files.
app.use(function(req, res, next) {
	// Interceptor.
	next();
});
app.use('/', express.static(__dirname + '/web'));
app.use('/rest', router);

var server = http.createServer(app);

// Start listening.
server.listen(port);
console.log('Listening on: http://localhost:' + port);

// Connect the socket.
socket.connect('tcp://localhost:5555');
socket.subscribe('');

// Close the socket on shutdown.
process.on('SIGINT', function() {
	socket.close();
	process.exit();
});
