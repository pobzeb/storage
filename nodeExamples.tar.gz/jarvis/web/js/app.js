"use strict";

(function() {
	var app = angular.module('jarvis', []);

	app.factory('DeviceManagerService', function($http) {
		return {
			authenticate: function(operator) {
				return $http.get('/rest/authenticate/'+operator);
			},
		};
	});

	// app.directive('topNavigation', function() {
	// 	return {
	// 		restrict: 'E',
	// 		templateUrl: 'templates/top-navigation.html'
	// 	};
	// });

	app.controller('ToolbarController', function($scope) {
		$scope.something = 'Toolbar';
	});

	app.controller('NavigationController', function($scope) {
		$scope.something = 'Navigation';
	});
	app.controller('MainContentController', function($scope) {
		$scope.something = 'Navigation';
	});

	app.controller('StatusbarController', function($scope) {
		$scope.something = 'Statusbar';
	});
})();
