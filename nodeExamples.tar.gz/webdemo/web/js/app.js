"use strict";

window.app = {
	templateCache: {},

	// Define the default headers.
	defaultHeaders: {
		"Accept": "application/json; charset=utf-8",
		"Content-Type": "application/json; charset=utf-8",
	},

	sortTable: function(tableId, columnId, invert) {
		if (invert == undefined) invert = false;
		var table = document.getElementById(tableId.substr(1));
		var dir = 1;
		if ($(columnId).data('dir') !== undefined) dir = parseInt($(columnId).data('dir'));
		dir = invert ? -dir : dir;
		$(columnId).data('dir', dir);
		$(table.getElementsByTagName('td')).filter(function() {
			return $(this).index() === table.getElementsByClassName(columnId.substr(1))[0].cellIndex;
		}).sortElements(function(a, b) {
			var sortDir = $.text([a]) > $.text([b]) ? 1 : -1;
			return dir * sortDir;
		}, function() {
			// parentNode is the element we want to move
			return this.parentNode;
		});
	},

	cacheTemplate: function(templatePath, callback) {
		$.get(templatePath, function(template) {
			app.templateCache[templatePath] = template;
			try { callback(); } catch(ex) {}
		});
	},

	getTemplate: function(name, data, dir) {
		var template = app.templateCache[dir+name+'.html'];
		if (template !== undefined) {
			// Compile the template and return the merged data.
			return Handlebars.compile(template)(data);
		}

		console.error(['app.getTemplate','Template not found in cache: '+dir+name+'.html']);
		return undefined;
	},

	sendRequest: function(url, method, requestData, callback, headers, dataType) {
		var that = this;
		// Merge passed in headers if there are any.
		if (!headers) {
			headers = $.extend(true, {}, app.defaultHeaders);
		}
		else {
			headers = $.extend(true, app.defaultHeaders, headers);
		}

		// Set the default dataType if none passed in.
		if (!dataType) {
			dataType = 'json';
		}
		console.debug('Calling ['+method+']: '+url);
		var requestData = (method.toLowerCase() != 'get' && dataType.toLowerCase() == 'json') ? JSON.stringify(requestData) : requestData;
		if (method.toLowerCase() !== 'get') {
			console.debug(['Message Body: ', requestData]);
		}
		$.ajax({
			url: url,
			type: method,
			headers: headers,
			dataType: dataType,
			async: true,
			cache: false,
			timeout: 20000,
			data: requestData,
			success: function(data) {
				try { callback(data); } catch(e) {}
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.error(['app.sendRequest','Error: ' + jqXHR.status + ' ' + textStatus + '\n' + errorThrown, 'While calling ['+method+']: '+url]);
				try { callback({status: jqXHR.status, message: textStatus, error_message: errorThrown, call_details: {method: method, url: url}}); }
				catch(e) {
					app.throwError(-1, 'Error: ' + jqXHR.status + ' ' + textStatus + ' - ' + errorThrown);
				}
			}
		});
	},

	addEventListener: function(eventUrl, callback) {
		// Connect up to the server event source.
		if (!!window.EventSource) {
			try {
				var eventSource = new EventSource(eventUrl);

				eventSource.onmessage = function(evt) {
					try { callback(evt.data); } catch(ex) {}
				};

				eventSource.onerror = function(evt) {
					console.error(evt);
				};
			}
			catch(ex) { console.error(['app.addEventListener',ex]); }
		}
		else {
			console.error(['app.addEventListener','Server side events are not supported in this browser!']);
		}
	},
};
