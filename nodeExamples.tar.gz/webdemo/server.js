// Pull in requirements.
var fs         = require('fs');
var express    = require('express');
var http       = require('http');
var bodyParser = require('body-parser');
var events     = require('events');

// Usage message.
var Usage      = 'Usage: nodejs server.js --config <PATH_TO_CONFIG>';

// Default mode.
var mode = 'dev';

// Default port.
var port = 8080;

// Load up the configuration file.
if (process.argv.length > 2) {
	var paramType = '';
	for (var idx = 2; idx < process.argv.length; idx++) {
		if (process.argv[idx].indexOf('--') == 0) {
			paramType = process.argv[idx].substr(2);
		}
		else {
			switch (paramType.toLowerCase()) {
				case 'config': {
					console.log('Loading Config: ' + process.argv[idx]);
					var configLines = fs.readFileSync(process.argv[idx], 'utf-8').split('\n');
					for (var lineIdx = 0; lineIdx < configLines.length; lineIdx++) {
						var key = configLines[lineIdx].split('=')[0];
						var val = configLines[lineIdx].split('=')[1];
						switch (key.toLowerCase()) {
							case 'mode': {
								if (val.toLowerCase() !== 'prod')
									mode = 'dev';
								else
									mode = 'prod';

								console.log('Application Mode: '+mode);
								break;
							}
							case 'port': {
								port = parseInt(val);
								break;
							}
						}
					}
					break;
				}
				default: {}
			}
		}
	}
}
else {
	console.error(usage);
	return;
}

// Event emitter.
var emitter = new events.EventEmitter();

// Create some data for the table.
// Stock Prices of course.
var tableData = {};
tableData['row0'] = {id:0, name:'Boeing', price:134.22, change:0.00, percent:0.000};
tableData['row1'] = {id:1, name:'JPMorgan Chase', price:352.20, change:0.00, percent:0.000};
tableData['row2'] = {id:2, name:'Time Warner', price:573.52, change:0.00, percent:0.000};
tableData['row3'] = {id:3, name:'Apple', price:682.93, change:0.00, percent:0.000};
tableData['row3'] = {id:3, name:'Google', price:235.53, change:0.00, percent:0.000};

// Create an interval to update the stock prices.
var stockInterval = setInterval(function() {
	// Pick a random row and adjust the price.
	var rowId = 'row'+Math.floor(Math.random() * Object.keys(tableData).length);
	var changeDirection = Math.round(Math.random()) == 1 ? 1 : -1;
	var priceChange = Math.random() * 25.00 * changeDirection;

	// Set the new price.
	tableData[rowId].price = tableData[rowId].price + priceChange;

	// Save the change and percent.
	tableData[rowId].change = Math.abs(priceChange) * changeDirection;
	tableData[rowId].percent = Math.abs(priceChange / tableData[rowId].price) * changeDirection;

	// Trigger a change notification.
	console.log(JSON.stringify({id:tableData[rowId].id, row:rowId, dir:changeDirection, price:tableData[rowId].price, change:tableData[rowId].change, percent:tableData[rowId].percent}));
	emitter.emit('change', {'id':tableData[rowId].id, 'row':rowId, 'dir':changeDirection, 'price':tableData[rowId].price, 'change':tableData[rowId].change, 'percent':tableData[rowId].percent});
}, 1000);

// Set up our endpoint routes.
var router = express.Router();
router.use(function(req, res, next) {
	// Endpoint request interceptor.
	next();
});

// Endpoint to get table snapshot.
router.route('/table/snapshot').get(function(req, res) {
	res.json(tableData);
});

// Endpoint to get a single row.
router.route('/table/row/:id').get(function(req, res) {
	// Get the rowid parameter from the request.
	var rowId = 'row'+parseInt(req.params.id);

	// Check the rowId to see if it is valid.
	if (rowId !== undefined && tableData[rowId] !== undefined) {
		// Return the JSON row.
		res.json(tableData[rowId]);
	}
	else {
		// Return an error message.
		res.json({error:'Invalid row id: '+rowId});
	}
});

// Endpoint to add a single row.
router.route('/table/row/:name/:price').put(function(req, res) {
	// Get the new name and price from the request.
	var name = req.params.name;
	var price = parseFloat(req.params.price);

	// Get the next available rowId.
	var rowId = Object.keys(tableData).length;

	// Add the new row.
	tableData['row'+rowId] = {'id':rowId, 'name':name, 'price':price, 'change':0.00, 'percent':0.000};

	// Trigger a change notification.
	rowId = 'row'+rowId;
	emitter.emit('change', {'id':tableData[rowId].id, 'row':rowId, 'dir':1, 'price':tableData[rowId].price, 'change':tableData[rowId].change, 'percent':tableData[rowId].percent});

	// Return the JSON row.
	res.json(tableData[rowId]);
});

// SSE endpoint to receive live updates.
router.route('/table/events').get(function(req, res) {
	// Hold the request open until the client closes it.
	req.socket.setTimeout(Infinity);

	// Create the event processor.
	this.processor = function(row) {
		// Send back the change.
		res.write('id: Change\n');
		res.write('data: '+JSON.stringify(row)+'\n\n');
	}

	// Create an emitter to sense changes.
	emitter.on('change', this.processor);

	// Send back a header for this stream.
	res.writeHead(200, {
		'Content-Type': 'text/event-stream',
		'Cache-Control': 'no-cache',
		'Connection': 'keep-alive'
	});
	res.write('\n');

	var that = this;
	req.on('close', function() {
		emitter.removeListener('change', that.processor);
	});
});

// Create the app.
var app = express();

// Used to parse json body.
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Add static files.
app.use(function(req, res, next) {
	// Request interceptor.
	next();
});
app.use('/', express.static(__dirname + '/web'));
app.use('/rest', router);

var server = http.createServer(app);

// Start listening.
server.listen(port);
console.log('Listening on: http://localhost:' + port);

// Close the socket on shutdown.
process.on('SIGINT', function() {
	clearInterval(stockInterval);
	process.exit();
});
